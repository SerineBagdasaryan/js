const express = require('express');
const fileUpload = require('express-fileupload');
const app = express();

// default options
app.use(fileUpload());

app.post('/upload', function(req, res) {   /* upload@ papki anunn e */
    if (!req.files)
        return res.status(400).send('No files were uploaded.');

    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.file;// inpuut dashti anunn

    // Use the mv() method to place the file somewhere on your server

        sampleFile.mv('file_upload/'+sampleFile.name, function(err) { /* en papki anynn vori mej bdi @knin uplod exac filern*/
        if (err)
            return res.status(500).send(err);

        res.send('File uploaded!');
    });
});
var server = app.listen(8081, function () {

    var host = server.address().address
    var port = server.address().port

    console.log("Example app listening at http://%s:%s", host, port)
})
const express= require('express');
const fileUpload=require('express_fileUpload');
const app=express();
app.use(fileUpload());
app.post('/upload',function (req, ress) {
    if(!req.files)
        return res.status(400).send('no');
})
let samplefile=req.files.file;
samplefile.mv('file_upload/',samplefile.name, function () {
    if(err)
        return res.status(500).send(err);
    res.send('file uploded');
})
var server = app.listen(8081,function () {
    var host = server.address().address
    var port = server.address.port
})
console.log('geeqe', port, host)